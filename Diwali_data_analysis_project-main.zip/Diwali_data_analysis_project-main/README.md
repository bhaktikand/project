# Diwali_data_analysis_project
In this project ,I have tool sales of a online website of india in this diwali , then i have performed data cleaning on it and then have visualised the data using pandas, matplot and 
seaborn in python .
I have provided insights on diwali sales for online shipping companies.
